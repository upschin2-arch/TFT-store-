import React from "react";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { addToCart } from "../redux/cartSlice";

const ProductCard = ({ product }) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const discount = Math.round(
    ((product.originalPrice - product.price) / product.originalPrice) * 100
  );

  return (
    <div style={{
      background: "#fff",
      border: "1px solid #e0e0e0",
      borderRadius: "4px",
      padding: "16px",
      cursor: "pointer",
      transition: "box-shadow 0.2s",
    }}
      onMouseEnter={(e) => e.currentTarget.style.boxShadow = "0 4px 20px rgba(0,0,0,0.15)"}
      onMouseLeave={(e) => e.currentTarget.style.boxShadow = "none"}
    >
      <img
        src={product.image}
        alt={product.name}
        onClick={() => navigate(`/product/${product.id || product._id}`)}
        style={{ width: "100%", height: "200px", objectFit: "cover", borderRadius: "4px", cursor: "pointer" }}
      />
      <div style={{ marginTop: "12px" }}>
        <p style={{ fontSize: "14px", color: "#212121", marginBottom: "4px" }}>{product.name}</p>
        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
          <span style={{ fontSize: "18px", fontWeight: "700" }}>₹{product.price}</span>
          <span style={{ fontSize: "13px", color: "#878787", textDecoration: "line-through" }}>₹{product.originalPrice}</span>
          <span style={{ fontSize: "13px", color: "#388e3c", fontWeight: "600" }}>{discount}% off</span>
        </div>
        <p style={{ fontSize: "12px", color: "#878787", marginTop: "4px" }}>Size: {product.size} · {product.condition}</p>
        <button
          onClick={() => dispatch(addToCart(product))}
          style={{
            width: "100%",
            marginTop: "12px",
            background: "#ff9f00",
            border: "none",
            padding: "10px",
            fontWeight: "700",
            fontSize: "14px",
            cursor: "pointer",
            borderRadius: "4px"
          }}>
          Add to Cart
        </button>
      </div>
    </div>
  );
};

export default ProductCard;
