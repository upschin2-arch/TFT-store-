import React, { useState } from "react";
import { useSelector } from "react-redux";
import { Link, useNavigate } from "react-router-dom";

const Navbar = () => {
  const [search, setSearch] = useState("");
  const totalItems = useSelector((state) => state.cart.totalItems);
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user"));

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    window.location.href = "/";
  };

  return (
    <nav style={{
      background: "#2874f0",
      padding: "12px 24px",
      display: "flex",
      alignItems: "center",
      gap: "16px",
      position: "sticky",
      top: 0,
      zIndex: 100
    }}>
      <div onClick={() => navigate("/")} style={{ cursor: "pointer" }}>
        <span style={{ color: "white", fontWeight: "700", fontSize: "22px" }}>TFT</span>
        <span style={{ fontSize: "10px", display: "block", color: "#ffe500" }}>
          Thrifted For Them
        </span>
      </div>

      <div style={{ flex: 1, display: "flex" }}>
        <input
          type="text"
          placeholder="Search thrifted clothes..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{
            width: "100%",
            padding: "10px 16px",
            border: "none",
            fontSize: "14px",
            outline: "none"
          }}
        />
        <button style={{
          background: "#ffe500",
          border: "none",
          padding: "0 20px",
          cursor: "pointer",
          fontSize: "18px"
        }}>🔍</button>
      </div>

      <div style={{ display: "flex", gap: "24px", color: "white", fontSize: "14px", alignItems: "center" }}>
        {user ? (
          <>
            <span>👤 {user.name}</span>
            <Link to="/admin" style={{ color: "#ffe500", textDecoration: "none" }}>Admin</Link>
            <span onClick={handleLogout} style={{ cursor: "pointer", color: "#ffe500" }}>Logout</span>
          </>
        ) : (
          <Link to="/login" style={{ color: "white", textDecoration: "none" }}>Login</Link>
        )}
        <Link to="/cart" style={{ color: "white", textDecoration: "none" }}>
          🛒 Cart {totalItems > 0 && (
            <span style={{
              background: "#ff6161",
              borderRadius: "50%",
              padding: "2px 7px",
              fontSize: "12px",
              fontWeight: "700"
            }}>
              {totalItems}
            </span>
          )}
        </Link>
      </div>
    </nav>
  );
};

export default Navbar;
