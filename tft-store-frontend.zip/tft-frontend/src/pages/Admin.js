import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const Admin = () => {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user"));
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState("");
  const [error, setError] = useState("");

  const [product, setProduct] = useState({
    name: "", price: "", originalPrice: "",
    category: "Jackets", size: "M", condition: "Good", image: "",
  });

  if (!user) { navigate("/login"); return null; }

  const handleChange = (e) => setProduct({ ...product, [e.target.name]: e.target.value });

  const handleSubmit = async () => {
    setLoading(true); setError(""); setSuccess("");
    try {
      await axios.post("http://localhost:5000/api/products", product);
      setSuccess("Product added successfully! ✅");
      setProduct({ name: "", price: "", originalPrice: "", category: "Jackets", size: "M", condition: "Good", image: "" });
    } catch (err) {
      setError("Something went wrong!");
    }
    setLoading(false);
  };

  const inputStyle = {
    width: "100%", border: "1px solid #e0e0e0", padding: "12px 16px",
    fontSize: "14px", outline: "none", borderRadius: "4px", marginBottom: "16px",
    boxSizing: "border-box", fontFamily: "inherit",
  };

  const labelStyle = { fontSize: "13px", color: "#878787", marginBottom: "6px", display: "block" };

  return (
    <div style={{ maxWidth: "700px", margin: "0 auto", padding: "32px 24px" }}>
      <h2 style={{ fontSize: "24px", marginBottom: "8px" }}>Admin Panel 🔧</h2>
      <p style={{ color: "#878787", marginBottom: "32px", fontSize: "14px" }}>Add new thrifted products to the store</p>

      <div style={{ background: "#fff", border: "1px solid #e0e0e0", borderRadius: "4px", padding: "32px" }}>
        <h3 style={{ fontSize: "18px", marginBottom: "24px" }}>Add New Product</h3>

        <label style={labelStyle}>Product Name</label>
        <input style={inputStyle} name="name" placeholder="e.g. Vintage Denim Jacket" value={product.name} onChange={handleChange} />

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px" }}>
          <div>
            <label style={labelStyle}>Sale Price (₹)</label>
            <input style={inputStyle} name="price" type="number" placeholder="649" value={product.price} onChange={handleChange} />
          </div>
          <div>
            <label style={labelStyle}>Original Price (₹)</label>
            <input style={inputStyle} name="originalPrice" type="number" placeholder="1800" value={product.originalPrice} onChange={handleChange} />
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "16px" }}>
          <div>
            <label style={labelStyle}>Category</label>
            <select style={inputStyle} name="category" value={product.category} onChange={handleChange}>
              {["Jackets", "Tops", "Dresses", "Bottoms", "Skirts"].map(c => <option key={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label style={labelStyle}>Size</label>
            <select style={inputStyle} name="size" value={product.size} onChange={handleChange}>
              {["XS", "S", "M", "L", "XL"].map(s => <option key={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label style={labelStyle}>Condition</label>
            <select style={inputStyle} name="condition" value={product.condition} onChange={handleChange}>
              {["Like New", "Good", "Fair"].map(c => <option key={c}>{c}</option>)}
            </select>
          </div>
        </div>

        <label style={labelStyle}>Image URL</label>
        <input style={inputStyle} name="image" placeholder="https://images.unsplash.com/..." value={product.image} onChange={handleChange} />

        {product.image && (
          <img src={product.image} alt="preview" style={{
            width: "100%", height: "200px", objectFit: "cover",
            borderRadius: "4px", marginBottom: "16px", border: "1px solid #e0e0e0"
          }} />
        )}

        {success && <p style={{ color: "#388e3c", marginBottom: "16px", fontSize: "14px" }}>{success}</p>}
        {error && <p style={{ color: "red", marginBottom: "16px", fontSize: "14px" }}>{error}</p>}

        <button onClick={handleSubmit} disabled={loading} style={{
          width: "100%", background: "#2874f0", color: "white", border: "none",
          padding: "14px", fontSize: "16px", fontWeight: "700", cursor: "pointer",
          borderRadius: "4px", fontFamily: "inherit"
        }}>
          {loading ? "Adding..." : "ADD PRODUCT"}
        </button>
      </div>
    </div>
  );
};

export default Admin;
