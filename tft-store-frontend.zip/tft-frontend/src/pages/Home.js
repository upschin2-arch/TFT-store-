import React from "react";
import ProductCard from "../components/ProductCard";
import products from "../data/products";

const categories = ["All", "Jackets", "Tops", "Dresses", "Bottoms", "Skirts"];

const Home = () => {
  const [selectedCategory, setSelectedCategory] = React.useState("All");

  const filtered = products.filter(p =>
    selectedCategory === "All" ? true : p.category === selectedCategory
  );

  return (
    <div>
      {/* Banner */}
      <div style={{
        background: "linear-gradient(135deg, #2874f0, #0a35ab)",
        color: "white",
        padding: "60px 40px",
        textAlign: "center"
      }}>
        <h1 style={{ fontSize: "36px", marginBottom: "12px" }}>Shop Thrifted Fashion 👗</h1>
        <p style={{ fontSize: "16px", marginBottom: "24px" }}>Upto 70% off on pre-loved clothes</p>
        <button style={{
          background: "#ffe500",
          color: "#2874f0",
          border: "none",
          padding: "12px 32px",
          fontSize: "16px",
          fontWeight: "700",
          cursor: "pointer",
          borderRadius: "4px"
        }}>
          Shop Now
        </button>
      </div>

      {/* Categories */}
      <div style={{
        display: "flex",
        gap: "12px",
        padding: "24px",
        justifyContent: "center",
        flexWrap: "wrap",
        background: "#f1f3f6"
      }}>
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            style={{
              background: selectedCategory === cat ? "#2874f0" : "#fff",
              color: selectedCategory === cat ? "#fff" : "#212121",
              border: "1px solid #e0e0e0",
              borderRadius: "4px",
              padding: "10px 24px",
              cursor: "pointer",
              fontWeight: "600",
              fontSize: "14px",
              fontFamily: "inherit"
            }}>
            {cat}
          </button>
        ))}
      </div>

      {/* Products Grid */}
      <div style={{ padding: "32px 24px", maxWidth: "1200px", margin: "0 auto" }}>
        <h2 style={{ marginBottom: "20px", fontSize: "22px" }}>
          {selectedCategory === "All" ? "Latest Drops 🔥" : selectedCategory}
        </h2>
        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))",
          gap: "20px"
        }}>
          {filtered.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default Home;
