const products = [
  {
    id: 1,
    name: "Vintage Denim Jacket",
    price: 649,
    originalPrice: 1800,
    category: "Jackets",
    size: "M",
    condition: "Like New",
    image: "https://images.unsplash.com/photo-1578932750294-f5075e85f44a?w=400"
  },
  {
    id: 2,
    name: "90s Floral Midi Dress",
    price: 499,
    originalPrice: 1400,
    category: "Dresses",
    size: "S",
    condition: "Good",
    image: "https://images.unsplash.com/photo-1572804013427-4d7ca7268217?w=400"
  },
  {
    id: 3,
    name: "Oversized Checked Shirt",
    price: 349,
    originalPrice: 999,
    category: "Tops",
    size: "L",
    condition: "Good",
    image: "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=400"
  },
  {
    id: 4,
    name: "High Waist Mom Jeans",
    price: 599,
    originalPrice: 1600,
    category: "Bottoms",
    size: "M",
    condition: "Like New",
    image: "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=400"
  },
  {
    id: 5,
    name: "Retro Bomber Jacket",
    price: 799,
    originalPrice: 2200,
    category: "Jackets",
    size: "L",
    condition: "Like New",
    image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=400"
  },
  {
    id: 6,
    name: "Y2K Mini Skirt",
    price: 249,
    originalPrice: 700,
    category: "Skirts",
    size: "XS",
    condition: "Like New",
    image: "https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?w=400"
  },
  {
    id: 7,
    name: "Cottagecore Blouse",
    price: 299,
    originalPrice: 850,
    category: "Tops",
    size: "S",
    condition: "Good",
    image: "https://images.unsplash.com/photo-1564257631407-4deb1f99d992?w=400"
  },
  {
    id: 8,
    name: "Vintage Corduroy Pants",
    price: 449,
    originalPrice: 1200,
    category: "Bottoms",
    size: "M",
    condition: "Good",
    image: "https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=400"
  },
];

export default products;
