import React, { useState } from "react";
import ProductCard from "../components/ProductCard";
import products from "../data/products";

const categories = ["All", "Jackets", "Tops", "Dresses", "Bottoms", "Skirts"];
const sizes = ["All", "XS", "S", "M", "L", "XL"];

const Home = () => {
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [selectedSize, setSelectedSize] = useState("All");
  const [sortBy, setSortBy] = useState("default");

  const filtered = products
    .filter((p) => selectedCategory === "All" || p.category === selectedCategory)
    .filter((p) => selectedSize === "All" || p.size === selectedSize)
    .sort((a, b) => {
      if (sortBy === "low") return a.price - b.price;
      if (sortBy === "high") return b.price - a.price;
      if (sortBy === "discount") return (b.originalPrice - b.price) - (a.originalPrice - a.price);
      return 0;
    });

  return (
    <div>
      {/* Banner */}
      <div style={{
        background: "linear-gradient(135deg, #2874f0, #0a35ab)",
        color: "white",
        padding: "60px 40px",
        textAlign: "center"
      }}>
        <h1 style={{ fontSize: "36px", marginBottom: "12px" }}>Shop Thrifted Fashion 👗</h1>
        <p style={{ fontSize: "16px", marginBottom: "24px" }}>Upto 70% off on pre-loved clothes</p>
        <button style={{
          background: "#ffe500",
          color: "#2874f0",
          border: "none",
          padding: "12px 32px",
          fontSize: "16px",
          fontWeight: "700",
          cursor: "pointer",
          borderRadius: "4px"
        }}>
          Shop Now
        </button>
      </div>

      {/* Filters */}
      <div style={{
        background: "#fff",
        borderBottom: "1px solid #e0e0e0",
        padding: "16px 24px",
        display: "flex",
        gap: "12px",
        alignItems: "center",
        flexWrap: "wrap"
      }}>
        {categories.map((c) => (
          <button key={c}
            onClick={() => setSelectedCategory(c)}
            style={{
              background: selectedCategory === c ? "#2874f0" : "transparent",
              color: selectedCategory === c ? "white" : "#2874f0",
              border: "1px solid #2874f0",
              padding: "6px 14px",
              fontSize: "13px",
              cursor: "pointer",
              borderRadius: "4px",
              fontFamily: "inherit"
            }}>
            {c}
          </button>
        ))}
        <select
          value={selectedSize}
          onChange={(e) => setSelectedSize(e.target.value)}
          style={{
            border: "1px solid #e0e0e0",
            padding: "8px 12px",
            fontSize: "13px",
            cursor: "pointer",
            outline: "none",
            borderRadius: "4px"
          }}>
          {sizes.map((s) => <option key={s}>{s}</option>)}
        </select>
        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value)}
          style={{
            border: "1px solid #e0e0e0",
            padding: "8px 12px",
            fontSize: "13px",
            cursor: "pointer",
            outline: "none",
            borderRadius: "4px"
          }}>
          <option value="default">Sort: Default</option>
          <option value="low">Price: Low to High</option>
          <option value="high">Price: High to Low</option>
          <option value="discount">Most Discounted</option>
        </select>
      </div>

      {/* Products Grid */}
      <div style={{ padding: "32px 24px" }}>
        <h2 style={{ marginBottom: "20px", fontSize: "22px" }}>
          Latest Drops 🔥 <span style={{ fontSize: "14px", color: "#878787" }}>({filtered.length} items)</span>
        </h2>
        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))",
          gap: "20px"
        }}>
          {filtered.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      </div>
    </div>
  );
};

export default Home;
