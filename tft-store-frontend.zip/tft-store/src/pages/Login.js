import React, { useState } from "react";
import { loginUser, registerUser } from "../utils/api";

const Login = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isSignup, setIsSignup] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    setLoading(true);
    setError("");
    try {
      const { data } = isSignup
        ? await registerUser({ name, email, password })
        : await loginUser({ email, password });
      localStorage.setItem("token", data.token);
      localStorage.setItem("user", JSON.stringify(data.user));
      window.location.href = "/";
    } catch (err) {
      setError(err.response?.data?.msg || "Something went wrong");
    }
    setLoading(false);
  };

  const inputStyle = {
    width: "100%",
    border: "none",
    borderBottom: "1px solid #e0e0e0",
    padding: "12px 0",
    fontSize: "15px",
    outline: "none",
    marginBottom: "24px",
    boxSizing: "border-box"
  };

  return (
    <div style={{
      minHeight: "80vh", display: "flex",
      alignItems: "center", justifyContent: "center", background: "#f1f3f6"
    }}>
      <div style={{
        display: "grid", gridTemplateColumns: "1fr 1fr",
        background: "#fff", borderRadius: "4px",
        overflow: "hidden", boxShadow: "0 2px 20px rgba(0,0,0,0.1)", width: "750px"
      }}>
        <div style={{ background: "#2874f0", padding: "48px 32px", color: "white" }}>
          <h2 style={{ fontSize: "28px", fontWeight: "700", marginBottom: "12px" }}>
            {isSignup ? "Join TFT!" : "Login to TFT"}
          </h2>
          <p style={{ fontSize: "16px", opacity: 0.9, lineHeight: 1.6 }}>
            Get access to your Orders, Wishlist and Recommendations
          </p>
          <div style={{ marginTop: "40px", fontSize: "13px", opacity: 0.8 }}>
            ♻️ Shop sustainable · Save more
          </div>
        </div>

        <div style={{ padding: "48px 32px" }}>
          {isSignup && (
            <input type="text" placeholder="Full Name" value={name}
              onChange={(e) => setName(e.target.value)} style={inputStyle} />
          )}
          <input type="email" placeholder="Email" value={email}
            onChange={(e) => setEmail(e.target.value)} style={inputStyle} />
          <input type="password" placeholder="Password" value={password}
            onChange={(e) => setPassword(e.target.value)} style={inputStyle} />

          {error && <p style={{ color: "red", fontSize: "13px", marginBottom: "16px" }}>{error}</p>}

          <button onClick={handleSubmit} disabled={loading} style={{
            width: "100%", background: "#fb641b", color: "white",
            border: "none", padding: "14px", fontSize: "16px",
            fontWeight: "700", cursor: "pointer", borderRadius: "4px", marginBottom: "16px"
          }}>
            {loading ? "Please wait..." : isSignup ? "SIGN UP" : "LOGIN"}
          </button>

          <p onClick={() => setIsSignup(!isSignup)}
            style={{ textAlign: "center", color: "#2874f0", cursor: "pointer", fontSize: "14px" }}>
            {isSignup ? "Already have account? Login" : "New to TFT? Create Account"}
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
