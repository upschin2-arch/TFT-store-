import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { addToCart } from "../redux/cartSlice";
import products from "../data/products";

const ProductDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const product = products.find((p) => p.id === parseInt(id));

  if (!product) return (
    <div style={{ textAlign: "center", padding: "80px" }}>
      <h2>Product not found!</h2>
    </div>
  );

  const discount = Math.round(
    ((product.originalPrice - product.price) / product.originalPrice) * 100
  );

  return (
    <div style={{ maxWidth: "1100px", margin: "0 auto", padding: "32px 24px" }}>
      <button onClick={() => navigate("/")} style={{
        background: "none", border: "none", color: "#2874f0",
        fontSize: "14px", cursor: "pointer", marginBottom: "24px", padding: 0
      }}>
        ← Back to Shop
      </button>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "48px" }}>
        <img src={product.image} alt={product.name} style={{
          width: "100%", height: "480px", objectFit: "cover",
          borderRadius: "4px", border: "1px solid #e0e0e0"
        }} />

        <div>
          <h1 style={{ fontSize: "24px", fontWeight: "600", marginBottom: "8px" }}>{product.name}</h1>
          <div style={{
            display: "inline-block", background: "#388e3c", color: "white",
            padding: "4px 10px", borderRadius: "4px", fontSize: "13px", marginBottom: "16px"
          }}>
            ✓ {product.condition}
          </div>

          <div style={{ marginBottom: "24px" }}>
            <span style={{ fontSize: "32px", fontWeight: "700" }}>₹{product.price}</span>
            <span style={{ fontSize: "16px", color: "#878787", textDecoration: "line-through", marginLeft: "12px" }}>
              ₹{product.originalPrice}
            </span>
            <span style={{ fontSize: "16px", color: "#388e3c", fontWeight: "700", marginLeft: "12px" }}>
              {discount}% off
            </span>
          </div>

          <div style={{ background: "#f8f8f8", borderRadius: "4px", padding: "20px", marginBottom: "24px" }}>
            <h3 style={{ fontSize: "16px", marginBottom: "12px" }}>Product Details</h3>
            <table style={{ width: "100%", fontSize: "14px", borderCollapse: "collapse" }}>
              {[
                ["Category", product.category],
                ["Size", product.size],
                ["Condition", product.condition],
                ["Delivery", "2-5 business days"],
              ].map(([key, val]) => (
                <tr key={key} style={{ borderBottom: "1px solid #e0e0e0" }}>
                  <td style={{ padding: "8px 0", color: "#878787", width: "40%" }}>{key}</td>
                  <td style={{ padding: "8px 0", fontWeight: "500" }}>{val}</td>
                </tr>
              ))}
            </table>
          </div>

          <div style={{ display: "flex", gap: "16px" }}>
            <button onClick={() => dispatch(addToCart(product))} style={{
              flex: 1, background: "#ff9f00", color: "white", border: "none",
              padding: "14px", fontSize: "16px", fontWeight: "700",
              cursor: "pointer", borderRadius: "4px"
            }}>
              🛒 ADD TO CART
            </button>
            <button onClick={() => { dispatch(addToCart(product)); navigate("/cart"); }} style={{
              flex: 1, background: "#fb641b", color: "white", border: "none",
              padding: "14px", fontSize: "16px", fontWeight: "700",
              cursor: "pointer", borderRadius: "4px"
            }}>
              ⚡ BUY NOW
            </button>
          </div>

          <div style={{ marginTop: "24px", padding: "16px", border: "1px solid #e0e0e0", borderRadius: "4px", fontSize: "14px" }}>
            <p>📦 <strong>Free Delivery</strong> on orders above ₹999</p>
            <p style={{ marginTop: "8px" }}>↩️ <strong>Easy Returns</strong> within 7 days</p>
            <p style={{ marginTop: "8px" }}>✅ <strong>100% Authentic</strong> thrifted items</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
