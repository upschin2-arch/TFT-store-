import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { removeFromCart, clearCart } from "../redux/cartSlice";

const Cart = () => {
  const { items, totalAmount, totalItems } = useSelector((state) => state.cart);
  const dispatch = useDispatch();

  if (items.length === 0) {
    return (
      <div style={{ textAlign: "center", padding: "80px 24px" }}>
        <div style={{ fontSize: "64px" }}>🛒</div>
        <h2 style={{ fontSize: "24px", marginTop: "16px" }}>Cart is Empty!</h2>
        <p style={{ color: "#878787", marginTop: "8px" }}>Add some thrifted clothes to your cart</p>
        <button
          onClick={() => window.location.href = "/"}
          style={{
            marginTop: "24px",
            background: "#2874f0",
            color: "white",
            border: "none",
            padding: "12px 32px",
            fontSize: "16px",
            fontWeight: "700",
            cursor: "pointer",
            borderRadius: "4px"
          }}>
          Shop Now
        </button>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: "1100px", margin: "0 auto", padding: "24px" }}>
      <h2 style={{ fontSize: "22px", marginBottom: "24px" }}>My Cart ({totalItems} items)</h2>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 340px", gap: "24px" }}>
        <div>
          {items.map((item) => (
            <div key={item.id} style={{
              background: "#fff",
              border: "1px solid #e0e0e0",
              borderRadius: "4px",
              padding: "20px",
              marginBottom: "16px",
              display: "flex",
              gap: "20px",
              alignItems: "center"
            }}>
              <img src={item.image} alt={item.name}
                style={{ width: "100px", height: "100px", objectFit: "cover", borderRadius: "4px" }} />
              <div style={{ flex: 1 }}>
                <p style={{ fontSize: "16px", fontWeight: "600", marginBottom: "6px" }}>{item.name}</p>
                <p style={{ fontSize: "13px", color: "#878787", marginBottom: "8px" }}>
                  Size: {item.size} · {item.condition}
                </p>
                <p style={{ fontSize: "18px", fontWeight: "700" }}>
                  ₹{item.price}
                  <span style={{ fontSize: "13px", color: "#878787", textDecoration: "line-through", marginLeft: "8px" }}>
                    ₹{item.originalPrice}
                  </span>
                </p>
                <p style={{ fontSize: "13px", color: "#388e3c", marginTop: "4px" }}>Qty: {item.qty}</p>
              </div>
              <button onClick={() => dispatch(removeFromCart(item.id))}
                style={{
                  background: "none", border: "1px solid #e0e0e0",
                  padding: "8px 16px", cursor: "pointer", color: "#878787",
                  borderRadius: "4px", fontSize: "13px"
                }}>
                Remove
              </button>
            </div>
          ))}
          <button onClick={() => dispatch(clearCart())}
            style={{
              background: "none", border: "1px solid #e0e0e0",
              padding: "10px 24px", cursor: "pointer", color: "#878787",
              borderRadius: "4px", fontSize: "14px"
            }}>
            Clear Cart
          </button>
        </div>

        <div style={{
          background: "#fff", border: "1px solid #e0e0e0",
          borderRadius: "4px", padding: "20px",
          position: "sticky", top: "80px", height: "fit-content"
        }}>
          <h3 style={{
            fontSize: "16px", color: "#878787",
            borderBottom: "1px solid #e0e0e0",
            paddingBottom: "12px", marginBottom: "16px", letterSpacing: "1px"
          }}>
            PRICE DETAILS
          </h3>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "12px" }}>
            <span>Price ({totalItems} items)</span>
            <span>₹{totalAmount}</span>
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "12px" }}>
            <span>Delivery Charges</span>
            <span style={{ color: "#388e3c" }}>{totalAmount > 999 ? "FREE" : "₹49"}</span>
          </div>
          <div style={{
            display: "flex", justifyContent: "space-between",
            borderTop: "1px solid #e0e0e0", paddingTop: "12px",
            marginTop: "12px", fontSize: "18px", fontWeight: "700"
          }}>
            <span>Total Amount</span>
            <span>₹{totalAmount > 999 ? totalAmount : totalAmount + 49}</span>
          </div>
          <p style={{ fontSize: "13px", color: "#388e3c", marginTop: "8px" }}>
            🎉 You are saving ₹{items.reduce((s, i) => s + (i.originalPrice - i.price) * i.qty, 0)} on this order!
          </p>
          <button style={{
            width: "100%", marginTop: "20px",
            background: "#fb641b", color: "white",
            border: "none", padding: "14px",
            fontSize: "16px", fontWeight: "700",
            cursor: "pointer", borderRadius: "4px"
          }}>
            PLACE ORDER
          </button>
        </div>
      </div>
    </div>
  );
};

export default Cart;
